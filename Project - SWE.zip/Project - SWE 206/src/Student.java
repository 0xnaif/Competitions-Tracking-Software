import javafx.beans.property.SimpleStringProperty;

public class Student{
	private int id;
	private String major;
	private String name;
	private String rank = "Unknown";
	

	public Student(int id, String major, String name) {

		this.id = id;
		this.major = major;
		this.name = name;
		/*this.namee = new SimpleStringProperty(name);
		this.idd = new SimpleStringProperty(id);
		this.majorr = new SimpleStringProperty(major);*/
	}

	public void setRank(String string) {
		this.rank = rank;
	}

	public String getName() {
		
		return name;
	}
	public int getId() {
		
		return id;
	}
	public String getRank() {

		return rank;
	}
	public String getMajor() {

		return major;
	}
	
	public String toString() {
		return String.format("ID: %-90d%-90s%1s", id, name, rank);
		
	}
	
	
}