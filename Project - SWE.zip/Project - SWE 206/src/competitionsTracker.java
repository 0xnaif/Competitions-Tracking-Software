import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class competitionsTracker extends Application {
	

	private static ArrayList<Competition> competitions = new ArrayList<Competition>();
	static TableView<Competition> tableViewC;
	static Button backfromScene2 = new Button("back");
	static Button backfromShowStudents = new Button("back");
	static Button backfromShowTeams = new Button("back");
	static Button backfromBrowse = new Button("back");
	static Button TrackButton = new Button("Track a new competition");
	static Button browseButton = new Button("Browse Website");

	public static void main(String[] args) throws Exception {
		
		// Just for test the code:
		CompetitionTB competition = new CompetitionTB("https://ultrahack.org/aiot-hackathon-stc","AIoT Hackathon with stc");
		competition.setDate(2021, 12, 20);
		CompetitionSolo competition2 = new CompetitionSolo("//twitter.com/CyberhubSa","CyberuHub");
		competition2.setDate(2021, 12, 22);
		Team team = new Team("SuperDevops", 1);
		Team team2 = new Team("StackUnderflow", 2);
		team.addStudent(new Student(222243860, "CS", "Bassel Alqahtani"));
		team.addStudent(new Student(222246560, "SWE", "Naif Essam"));
		team2.addStudent(new Student(222219260, "COE", "Majed Ahmad"));
		team2.addStudent(new Student(222267500, "COE", "Saleh Mohammed"));
		competition.addTeam(team);
		competition.addTeam(team2);
		addCompetition(competition);

		competition2.addStudent(new Student(222256561, "CS", "Ahmad Mohammed"));
		competition2.addStudent(new Student(222256560, "EE", "Abdullah Ali"));
		competition2.addStudent(new Student(222279260, "MIS", "Abdulaziz fawwaz"));
		competition2.addStudent(new Student(222256700, "SWE", "Faris Ahmad"));
		addCompetition(competition2);
	
		launch(args);
		
	}

	public static void addCompetition(CompetitionTB competition) {
		competitions.add(competition);
	}
	
	public static void addCompetition(CompetitionSolo competition) {
		competitions.add(competition);
	}
	public ArrayList<Competition> getCompetitions() {
		return competitions;
	}
	
//---------------------------------------------------------
	
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub

		Scene scene = showcompetitions();
		Scene scene2=  TrackCompetition();
		Scene scene3 = browse();
		
		backfromScene2.setPrefSize(90, 20);
		backfromScene2.setOnAction(e ->arg0.setScene(scene));
		
		backfromShowStudents.setPrefSize(90, 20);
		backfromShowStudents.setOnAction(e -> arg0.setScene(scene));
		
		backfromShowTeams.setPrefSize(90, 20);
		backfromShowTeams.setOnAction(e -> arg0.setScene(scene));
		
		backfromBrowse.setPrefSize(90, 20);
		backfromBrowse.setOnAction(e -> arg0.setScene(scene));
		
		TrackButton.setOnAction(e -> arg0.setScene(scene2));
		browseButton.setOnAction(e -> arg0.setScene(scene3));
		

    	arg0.setScene(scene);
    	arg0.show();
		
	}
	
	public Scene showcompetitions() {
		
		Label label = new Label("Competitions Page");
        label.setFont(new Font("Arial", 20));
        label.setPadding(new Insets(10, 10, 10, 10));
    	tableViewC = new TableView<Competition>();
    	tableViewC.setPrefSize(50, 500);
        	
    	TableColumn<Competition, Date> column1 = new TableColumn<>("Name");
        column1.setCellValueFactory(new PropertyValueFactory<>("name"));
        TableColumn<Competition, Date> column2 = new TableColumn<>("Date");
        column2.setCellValueFactory(new PropertyValueFactory<>("date"));
        TableColumn<Competition, String> column3 = new TableColumn<>("Type");
        column3.setCellValueFactory(new PropertyValueFactory<>("type"));
        TableColumn<Competition, Date> column4 = new TableColumn<>("Link");
        column4.setCellValueFactory(new PropertyValueFactory<>("link"));
		
        tableViewC.getColumns().add(column1);
        tableViewC.getColumns().add(column2);
        tableViewC.getColumns().add(column3);
        tableViewC.getColumns().add(column4);
     
        for(Competition competition : competitions)
        	tableViewC.getItems().add(competition);
        
        Button ShowPar = new Button("Show Participants");
        
        tableViewC.setOnMouseClicked((MouseEvent event) -> {
        	Competition selectedCompetition = tableViewC.getSelectionModel().getSelectedItem(); 
        	if(selectedCompetition instanceof CompetitionSolo)
        		ShowPar.setOnAction(e -> showStudents(e,selectedCompetition));
        	else if(selectedCompetition instanceof CompetitionTB)
        		ShowPar.setOnAction(e -> showTeams(e,selectedCompetition));
        });
        
        HBox hbox = new HBox();
        hbox.getChildren().addAll(ShowPar,browseButton,TrackButton);  
        hbox.setAlignment(Pos.CENTER);
        hbox.setSpacing(20);
        hbox.setPadding(new Insets(10, 10, 10, 10));
	
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(label); 
		borderPane.setCenter(tableViewC);
		borderPane.setBottom(hbox);  

    	Scene scene = new Scene(borderPane,810, 450);
        return scene;
	}
	
	public void showStudents(ActionEvent event,Competition competition) {

		if(competition != null) {
   	
			final Label label = new Label("Participants");
	        label.setFont(new Font("Arial", 20));
	    	TableView<Student> tableView = new TableView<Student>();
	    	tableView.setPrefSize(50, 500);
	        	
	        TableColumn<Student, Integer> column1 = new TableColumn<>("ID");
	        column1.setCellValueFactory(new PropertyValueFactory<>("id"));
	        TableColumn<Student, String> column2 = new TableColumn<>("Name");
	        column2.setCellValueFactory(new PropertyValueFactory<>("name"));
	        TableColumn<Student, String> column3 = new TableColumn<>("Rank");
	        column3.setCellValueFactory(new PropertyValueFactory<>("rank"));
	        TableColumn<Student, String> column4 = new TableColumn<>("Major");
	        column4.setCellValueFactory(new PropertyValueFactory<>("major"));
	
	        tableView.getColumns().add(column1);
	        tableView.getColumns().add(column2);
	        tableView.getColumns().add(column4);

	      
	        ArrayList<Student> individuals = ((CompetitionSolo) competition).getIndividuals();
			for(int i = 0;i < individuals.size();++i) {
				tableView.getItems().add(individuals.get(i));
				}
			
			final TextField addName = new TextField();
			addName.setPromptText("Name");
			addName.setMaxWidth(column1.getPrefWidth());
	        final TextField addId = new TextField();
	        addId.setMaxWidth(column2.getPrefWidth());
	        addId.setPromptText("ID");
	        final TextField setRank = new TextField();
	        setRank.setMaxWidth(column3.getPrefWidth());
	        setRank.setPromptText("Rank");
	        final TextField addMajor = new TextField();
	        addMajor.setMaxWidth(column4.getPrefWidth());
	        addMajor.setPromptText("Major");
			
	    	Label  IDView = new Label("ID : ", addId);
	    	Label  NameView = new Label("Name : ", addName);
	    	Label  MajorView = new Label("Major : ", addMajor);
	    	Label  RankView = new Label("Rank : ", setRank);
	    	
	    	IDView.setContentDisplay(ContentDisplay.RIGHT);
	    	NameView.setContentDisplay(ContentDisplay.RIGHT);
	    	MajorView.setContentDisplay(ContentDisplay.RIGHT);
	    	RankView.setContentDisplay(ContentDisplay.RIGHT);
	    	IDView.setPadding(new Insets(5, 5, 5, 5));
	    	NameView.setPadding(new Insets(5, 5, 5, 5));
	    	MajorView.setPadding(new Insets(5, 5, 5, 5));
	    	RankView.setPadding(new Insets(5, 5, 5, 5));
	    	
	        Button addButton = new Button("Add");
	        addButton.setPrefSize(90, 20);
	        
	        HBox hbox = new HBox();
	        hbox.getChildren().addAll(IDView,NameView,MajorView,RankView);
	        hbox.setAlignment(Pos.CENTER);
	        
	    	BorderPane BottomBorderPane = new BorderPane();
	    	BottomBorderPane.setPadding(new Insets(10, 10, 10, 10));
	    	BottomBorderPane.setCenter(hbox);
	    	BottomBorderPane.setLeft(backfromShowStudents);
	    	BottomBorderPane.setRight(addButton);

	        Button prepareEmail = new Button("Prepare email");
	        prepareEmail.setPrefSize(90, 20);
	        
	        BorderPane topBorder = new BorderPane();
	        topBorder.setPadding(new Insets(10, 10, 10, 10));
	        topBorder.setLeft(label);
	        topBorder.setRight(prepareEmail);
	        
			BorderPane borderPane = new BorderPane();
	        borderPane.setBottom(BottomBorderPane);
			borderPane.setCenter(tableView);
			borderPane.setTop(topBorder);
			
	        addButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override
	            public void handle(ActionEvent e) {
	            	Alert errorAlert = new Alert(AlertType.ERROR);
			      	errorAlert.setHeaderText("Invalid input");
	            	if(!addId.getText().isBlank() && !addMajor.getText().isBlank() && !addName.getText().isBlank() && !setRank.getText().isBlank()) {
	            		
	            		try {	
		            		Student student =new Student(Integer.parseInt(addId.getText()),addMajor.getText(),addName.getText());
		            		student.setRank(setRank.getText());
		            		((CompetitionSolo) competition).addStudent(student);
		            		addId.clear();
		            		addMajor.clear();
		            		addName.clear();
		            		setRank.clear();
		            		addId.setStyle("-fx-border-color: black");
		            		tableView.getItems().add(((CompetitionSolo) competition).getIndividuals().get(((CompetitionSolo) competition).getIndividuals().size()-1));
	            		 }
	        		    catch(NumberFormatException es) {
	        		      System.out.println("Cannot parse the string to integer");	        		   
	        		      errorAlert.setContentText("ID should be numbers");
	        		      errorAlert.showAndWait();
	        		    }
	            	}
	            	else {
	            		errorAlert.setContentText("Fill all information!");
	            		errorAlert.showAndWait();
	            	}
	            	
	            }
	        });
	        tableView.setOnMouseClicked((MouseEvent ev) -> {
	        	Student selectedStudent = tableView.getSelectionModel().getSelectedItem(); 
	        	prepareEmail.setOnAction(e -> {
	        	CompetitionManger Manger = new CompetitionManger(competition);
	        	
	        	try {Manger.prepareEmail(selectedStudent);} 
	        	catch (Exception e1) {e1.printStackTrace();}
	        	
	        	});
	        	
	        });
	    	Scene scene = new Scene(borderPane,810, 450);
	    	Node node = (Node) event.getSource();
	        Stage thisStage = (Stage) node.getScene().getWindow();
	        thisStage.setScene(scene);
	        thisStage.show();
        }

	}
	
	public Scene TrackCompetition() {
		
		TextField competitionName = new TextField();
		TextField competitionLink = new TextField();
		DatePicker datePicker = new DatePicker();
		competitionName.setPrefSize(500, 15);
		
		ComboBox<String> CompetitionType = new ComboBox<>();
		CompetitionType.setPrefSize(100, 20);
		CompetitionType.getItems().addAll("Solo", "Team Basd");
		CompetitionType.setValue(""); 

		Label competitionNameLable = new Label("Competition name:", competitionName);
		Label competitionLinkLable = new Label("Competition link:", competitionLink);
		Label typeLable = new Label("Competition type: ", CompetitionType);
		Label dateLable = new Label("Competition date: ", datePicker);
		
		typeLable.setContentDisplay(ContentDisplay.RIGHT);
		typeLable.setPadding(new Insets(10, 10, 10, 10));
		
		dateLable.setContentDisplay(ContentDisplay.RIGHT);
		dateLable.setPadding(new Insets(10, 10, 10, 10));

		competitionNameLable.setContentDisplay(ContentDisplay.RIGHT);
		competitionNameLable.setPadding(new Insets(10, 10, 10, 10));
		
		competitionLinkLable.setContentDisplay(ContentDisplay.RIGHT);
		competitionLinkLable.setPadding(new Insets(10, 10, 10, 10));
		

		VBox Vbox = new VBox(15);
		Vbox.getChildren().addAll(competitionNameLable, competitionLinkLable, typeLable, dateLable);
		Vbox.setPadding(new Insets(20, 10, 10, 20));

		Button Track = new Button("Track");
		Track.setPrefSize(90, 20);

		BorderPane borderPane1 = new BorderPane();
		borderPane1.setPadding(new Insets(0, 20, 20, 20));

		borderPane1.setLeft(backfromScene2);
		borderPane1.setRight(Track);
		

		BorderPane borderPane = new BorderPane();
		borderPane.setCenter(Vbox);
		borderPane.setBottom(borderPane1);
		
		Track.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent e) {
        	
        	Alert errorAlert = new Alert(AlertType.ERROR);
		      	errorAlert.setHeaderText("Invalid input");
		      	
		      	
        	if(!competitionName.getText().isBlank() && !competitionLink.getText().isBlank() && !CompetitionType.getValue().isBlank()) {
        		try {
        			
        			int year = datePicker.getValue().getYear();
            		int month =  datePicker.getValue().getMonth().getValue();
            		int day = datePicker.getValue().getDayOfMonth();

        			if(CompetitionType.getValue().equals("Solo")) {   
        				CompetitionSolo competition = new CompetitionSolo(competitionLink.getText(),competitionName.getText());
        				competition.setDate(year, month, day);
        				addCompetition(competition);
        				tableViewC.getItems().add(competition);}
        			else{
        				CompetitionTB competition = new CompetitionTB(competitionLink.getText(),competitionName.getText());
        				competition.setDate(year, month, day);
        				addCompetition(competition);
        				tableViewC.getItems().add(competition);}
        			
        			competitionAdded(e);
        			} 
	        	catch (Exception e1) {
	        		errorAlert.setContentText("Enter a date!!");
            		errorAlert.showAndWait();}
        		
    			competitionName.clear();
				competitionLink.clear();
				datePicker.setValue(null);
				CompetitionType.setValue("");
        	}
        	else {
        		errorAlert.setContentText("Fill all information");
        		errorAlert.showAndWait();
		      } 	
        }});

		Scene scene = new Scene(borderPane,700, 300);
    	return scene;
	}
	
	public void competitionAdded(ActionEvent event) {
		
		BorderPane borderPane = new BorderPane();
		Text text = new Text("The competition has been added successfully");
		text.setFont(Font.font(text.getText(), FontWeight.BOLD, FontPosture.REGULAR, 20));

		borderPane.setBottom(backfromScene2);
		borderPane.setPadding(new Insets(10, 10, 10, 10));
		borderPane.setCenter(text);
		
		Scene scene = new Scene(borderPane,700, 300);
		Node node = (Node) event.getSource();
        Stage thisStage = (Stage) node.getScene().getWindow();
        thisStage.setScene(scene);
        thisStage.show();
	}

	public Scene browse() {
		// note : add this Button (backfromBrowse). It is static Button.
		// To be completed
		
		
		
		BorderPane borderPane = new BorderPane();
		// Add to (borderPane)
		
		Scene scene = new Scene(borderPane,810, 450);
		return scene;
	}
	
	public void showTeams(ActionEvent event,Competition competition) {
		// note : add this Button (backfromShowTeams). It is static Button.
		// Look at start method I used (backfromShowTeams.setOnAction).
		
		if(competition != null) {
			// To be completed
		
		
			BorderPane borderPane = new BorderPane();
			// Add to (borderPane)
				
		   	Scene scene = new Scene(borderPane,810, 450);
			Node node = (Node) event.getSource();
		    Stage thisStage = (Stage) node.getScene().getWindow();
		    thisStage.setScene(scene);
		    thisStage.show();
        }
	}
	
	public void showTeamMembers(ActionEvent event,Competition competition, Team team) {
		
		// To be completed
		
		
		// Add this Button to the screen.
		Button back = new Button("back");
		back.setPrefSize(90, 20);
		back.setOnAction(e -> showTeams(e,competition));
		
		BorderPane borderPane = new BorderPane();
		// Add to (borderPane).
		
		Scene scene = new Scene(borderPane,810, 450);
		Node node = (Node) event.getSource();
	    Stage thisStage = (Stage) node.getScene().getWindow();
	    thisStage.setScene(scene);
	    thisStage.show();
	    
	}
	
	
}
